#!/usr/bin/env python
#coding:utf-8

class BaseAI:
	def getMove(self, grid):
		pass